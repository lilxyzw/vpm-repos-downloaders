﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using UnityEditor;

namespace jp.lilxyzw.lilpbr.downloader
{
    internal static class Downloader
    {
        const string PACKAGE_DIRECTORY = "Packages/jp.lilxyzw.lilpbr";
        const string URL = "https://downloads.fanbox.cc/files/post/10225049/GLAetiyd1IOoq3bWwumd8GiI.zip";
        const string FILE_NAME = "jp.lilxyzw.lilpbr-0.9.0*.zip";
        const int TIMEOUT_SECONDS = 120;
        const int INTERVAL_SECONDS = 1;

        [InitializeOnLoadMethod]
        private static void Main()
        {
            if (File.Exists("Temp/downloaded_jp.lilxyzw.lilpbr"))
            {
                File.Delete("Temp/downloaded_jp.lilxyzw.lilpbr");
                AssetDatabase.AllowAutoRefresh();
                AssetDatabase.Refresh();
                return;
            }
            if (File.Exists("Temp/downloading_jp.lilxyzw.lilpbr"))
            {
                return;
            }
            DoTask();
        }

        static async void DoTask()
        {
            File.Create("Temp/downloading_jp.lilxyzw.lilpbr");
            string downloadFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            Process.Start(new ProcessStartInfo(URL) { UseShellExecute = true });

            string downloadedFile = await WaitForDownload(downloadFolder, DateTime.Now);

            if (!string.IsNullOrEmpty(downloadedFile))
            {
                AssetDatabase.DisallowAutoRefresh();
                foreach (var path in Directory.GetFiles(PACKAGE_DIRECTORY, "*", SearchOption.AllDirectories)) File.Delete(path);
                ZipFile.ExtractToDirectory(downloadedFile, PACKAGE_DIRECTORY);
                File.Delete(downloadedFile);
                File.Delete("Temp/downloading_jp.lilxyzw.lilpbr");
                File.Create("Temp/downloaded_jp.lilxyzw.lilpbr");
                AssetDatabase.AllowAutoRefresh();
                AssetDatabase.Refresh();
            }
            else
            {
                throw new Exception("Download timed out or file not found.");
            }
        }

        private static async Task<string> WaitForDownload(string folder, DateTime afterTime)
        {
            int elapsed = 0;

            while (elapsed < TIMEOUT_SECONDS)
            {
                var files = Directory.GetFiles(folder, FILE_NAME)
                    .Select(f => new FileInfo(f))
                    .Where(f => f.CreationTime >= afterTime && !IsLocked(f))
                    .OrderByDescending(f => f.CreationTime);

                if (files.Any())
                    return files.First().FullName;

                await Task.Delay(INTERVAL_SECONDS * 1000);
                elapsed += INTERVAL_SECONDS;
            }

            return null;
        }

        private static bool IsLocked(FileInfo file)
        {
            try
            {
                using FileStream stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
                return false;
            }
            catch (IOException)
            {
                return true;
            }
        }
    }
}
